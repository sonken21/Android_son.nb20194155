package com.example.caculator;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
private Button bt0,bt1,bt2,bt3,bt4,bt5,bt6,bt7,bt8,bt9,btcong,bttru,btnhan,btchia,btketqua,btcongtru,btC,btCE,btcham,btBS;
private TextView textViewResult;

private String number=null;

double lastnumber=0, firstnumber=0;

boolean operator=false;
String status=null;

String pattern="###,###.####";
DecimalFormat decimalFormat=new DecimalFormat(pattern);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        bt0=this.findViewById(R.id.bt0);
        bt1=this.findViewById(R.id.bt1);
        bt2=this.findViewById(R.id.bt2);
        bt3=this.findViewById(R.id.bt3);
        bt4=this.findViewById(R.id.bt4);
        bt5=this.findViewById(R.id.bt5);
        bt6=this.findViewById(R.id.bt6);
        bt7=this.findViewById(R.id.bt7);
        bt8=this.findViewById(R.id.bt8);
        bt9=this.findViewById(R.id.bt9);

        btcong=this.findViewById(R.id.btcong);
        bttru=this.findViewById(R.id.bttru);
        btnhan=this.findViewById(R.id.btnhan);
        btchia=this.findViewById(R.id.btchia);

        btcham=this.findViewById(R.id.btcham);
        btC=this.findViewById(R.id.btC);
        btCE=this.findViewById(R.id.btCE);
        btBS=this.findViewById(R.id.btBS);
        btcongtru=this.findViewById(R.id.btcongtru);
        btketqua=this.findViewById(R.id.btketqua);
        textViewResult=this.findViewById(R.id.textViewResult);

        bt0.setOnClickListener(view -> numberclick("0"));
        bt1.setOnClickListener(view -> numberclick("1"));
        bt2.setOnClickListener(view -> numberclick("2"));
        bt3.setOnClickListener(view -> numberclick("3"));
        bt4.setOnClickListener(view -> numberclick("4"));
        bt5.setOnClickListener(view -> numberclick("5"));
        bt6.setOnClickListener(view -> numberclick("6"));
        bt7.setOnClickListener(view -> numberclick("7"));
        bt8.setOnClickListener(view -> numberclick("8"));
        bt9.setOnClickListener(view -> numberclick("9"));

        btcong.setOnClickListener(view -> {
            if(operator){
                if(status=="nhan"){
                    Nhan();
                }else{
                    if (status=="chia") {
                        Chia();
                    }else{
                        if(status=="tru"){
                            Tru();
                        }else{
                            Cong();
                        }
                    }
                }
            }
            operator=false;
            number=null;
            status="cong";
        });

        bttru.setOnClickListener(view -> {
            if(operator){
                if(status=="nhan"){
                    Nhan();
                }else{
                    if (status=="chia") {
                        Chia();
                    }else{
                        if(status=="cong"){
                            Cong();
                        }else{
                            Tru();
                        }
                    }
                }
            }
            operator=false;
            number=null;
            status="tru";
        });

        btnhan.setOnClickListener(view -> {
            if(operator){
                if(status=="cong"){
                    Cong();
                }else{
                    if (status=="chia") {
                        Chia();
                    }else{
                        if(status=="tru"){
                            Tru();
                        }else{
                            Nhan();
                        }
                    }
                }
            }
            operator=false;
            number=null;
            status="nhan";
        });

        btchia.setOnClickListener(view -> {
            if(operator){
                if(status=="nhan"){
                    Nhan();
                }else{
                    if (status=="cong") {
                        Cong();
                    }else{
                        if(status=="tru"){
                            Tru();
                        }else{
                            Chia();
                        }
                    }
                }
            }
            operator=false;
            number=null;
            status="chia";
        });
        btketqua.setOnClickListener(view->{
            if(operator) {
                if (status == "nhan") {
                    Nhan();
                } else {
                    if (status == "cong") {
                        Cong();
                    } else {
                        if (status == "tru") {
                            Tru();
                        } else
                        if(status=="chia"){
                            Chia();
                        }else{
                            firstnumber=Double.parseDouble(textViewResult.getText().toString());
                        }
                    }
                }
            }
            operator=false;
//            textViewResult.setText(number);
        });
        btCE.setOnClickListener(view ->{
            number=number.substring(0,number.length()-1);
            textViewResult.setText(number);
        });
        btcham.setOnClickListener(view->{
            if(number==null){
                number="0.";
            }else {
                number=number+".";
            }
            textViewResult.setText(number);
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void numberclick (String view){
        if(number==null){
            number=view;
        }else{
            number=number+view;
        }
        textViewResult.setText(number);
        operator=true;
    }

    public void Tru(){
        if(firstnumber==0){
            firstnumber=Double.parseDouble(textViewResult.getText().toString());
        }else {
            lastnumber=Double.parseDouble(textViewResult.getText().toString());
            firstnumber=firstnumber-lastnumber;
        }
        textViewResult.setText(decimalFormat.format(firstnumber));
    }
    public void Cong(){
        lastnumber=Double.parseDouble(textViewResult.getText().toString());
        firstnumber=firstnumber+lastnumber;
        textViewResult.setText(decimalFormat.format(firstnumber));
    }
    public void Nhan(){
        if(firstnumber==0){
            firstnumber=1;
        }
        lastnumber=Double.parseDouble(textViewResult.getText().toString());
        firstnumber=firstnumber*lastnumber;
        textViewResult.setText(decimalFormat.format(firstnumber));
    }
    public void Chia(){
        if(firstnumber==0){
            lastnumber=Double.parseDouble(textViewResult.getText().toString());
            firstnumber=lastnumber;
        }else {
            lastnumber=Double.parseDouble(textViewResult.getText().toString());
            firstnumber=firstnumber/lastnumber;
        }
        textViewResult.setText(decimalFormat.format(firstnumber));

    }
}