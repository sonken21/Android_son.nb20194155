package vn.edu.hust.studentman

data class StudentModel(val studentName: String, val studentId: String)
